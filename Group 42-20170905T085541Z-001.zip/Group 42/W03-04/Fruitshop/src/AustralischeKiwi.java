/**
 * Created by Jay on 13-3-2017.
 */
public class AustralischeKiwi {

    public void munch(){
        System.out.println("Shrimp on the barbey, oh no its me.");
    }
}
