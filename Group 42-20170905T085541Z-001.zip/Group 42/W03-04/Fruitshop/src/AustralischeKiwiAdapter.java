/**
 * Created by Jay on 13-3-2017.
 */
public class AustralischeKiwiAdapter implements Kiwi {
    AustralischeKiwi kiwi = new AustralischeKiwi();
    @Override
    public void eat() {
       kiwi.munch();
    }
}
