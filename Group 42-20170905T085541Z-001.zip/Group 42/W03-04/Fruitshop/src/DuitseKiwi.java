/**
 * Created by Jay on 13-3-2017.
 */
public class DuitseKiwi {
    public void essen(){
        System.out.println("Darf ich eine milkshake?");
    }
}
