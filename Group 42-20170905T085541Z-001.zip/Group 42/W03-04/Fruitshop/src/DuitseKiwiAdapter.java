/**
 * Created by Jay on 13-3-2017.
 */
public class DuitseKiwiAdapter implements Kiwi {
    DuitseKiwi kiwi = new DuitseKiwi();
    @Override
    public void eat() {
        kiwi.essen();
    }
}
