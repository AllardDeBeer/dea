/**
 * Created by Jay on 13-3-2017.
 */
public class FruitEter {
    KiwiFactory magic = new KiwiFactory();

    public void eetKiwi(){
    Kiwi lekkereKiwi = magic.MaakKiwi();
    lekkereKiwi.eat();
    }

        }

