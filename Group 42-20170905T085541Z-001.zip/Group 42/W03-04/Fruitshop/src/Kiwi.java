/**
 * Created by Jay on 13-3-2017.
 */
public interface Kiwi {
    public void eat();
}
