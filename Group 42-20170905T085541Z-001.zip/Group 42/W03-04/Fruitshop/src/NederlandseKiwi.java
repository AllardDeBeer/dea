/**
 * Created by Jay on 13-3-2017.
 */
public class NederlandseKiwi {
    public void eet(){
        System.out.println("Volgens mij word ik gegeten.");
    }
}
