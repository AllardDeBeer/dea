/**
 * Created by Jay on 13-3-2017.
 */
public class NederlandseKiwiAdapter implements Kiwi {
    NederlandseKiwi kiwi = new NederlandseKiwi();
    @Override
    public void eat() {
        kiwi.eet();
    }
}
