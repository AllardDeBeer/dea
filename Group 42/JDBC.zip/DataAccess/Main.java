package DataAccess;

/**
 * Created by Jay on 24-3-2017.
 */
public class Main {
    public static void main(String[] args) throws Exception{
        MYSQLAccess test = new MYSQLAccess();
           test.readDataBase();
           test.Insert(9002,"I'm alright-neil zaza");


    }
}
