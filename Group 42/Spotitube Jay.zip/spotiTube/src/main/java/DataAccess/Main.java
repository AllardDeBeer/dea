package DataAccess;

import nl.han.oose.programmeerOpdracht.Song;

/**
 * Created by Jay on 24-3-2017.
 */
public class Main {
    public static void main(String[] args) throws Exception{
        //MYSQLAccess test = new MYSQLAccess();
           //test.readDataBase();
          // test.Insert(9002,"I'm alright-neil zaza");
          //  test.deleteAll();
    SongDAOImpl tester = new SongDAOImpl();
   Song aapje = tester.getSong("title");
   System.out.println(aapje.getPerformer());
    }
}
