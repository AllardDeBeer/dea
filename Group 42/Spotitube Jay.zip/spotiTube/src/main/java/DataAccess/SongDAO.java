package DataAccess;

import nl.han.oose.programmeerOpdracht.Song;

/**
 * Created by Jay on 26-3-2017.
 */
public interface SongDAO {
    public Song getSong(String title) throws Exception;
    public String getAlbum(String title);
}
