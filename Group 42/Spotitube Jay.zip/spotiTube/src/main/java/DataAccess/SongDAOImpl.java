package DataAccess;

import nl.han.oose.programmeerOpdracht.Song;

import java.sql.*;

/**
 * Created by Jay on 26-3-2017.
 */
public class SongDAOImpl implements SongDAO {
    private Connection connect = null;
    private Statement statement = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    @Override
    public Song getSong(String title) throws Exception {
        try {
            // This will load the MySQL driver, each DB has its own driver
            Class.forName("com.mysql.jdbc.Driver");
            // Setup the connection with the DB
            connect = DriverManager
                    .getConnection("jdbc:mysql://localhost/spotitube?"
                            + "user=admin&password=admin");

            // Statements allow to issue SQL queries to the database
            statement = connect.createStatement();
            // Result set get the result of the SQL query
            resultSet = statement
                    .executeQuery("SELECT * FROM tracks WHERE title = '" +title+ "'");

            Song song = createSongObject(resultSet);
            return song;




        } catch (Exception e) {
            throw e;
        } finally {
            close();
        }
    }


    private void close() {
        try {
            if (resultSet != null) {
                resultSet.close();
            }

            if (statement != null) {
                statement.close();
            }

            if (connect != null) {
                connect.close();
            }
        } catch (Exception e) {

        }
    }


    private Song createSongObject(ResultSet resultSet) throws SQLException {
        int id = 0;
        String performer ="0";
        String titel="0";
        String url = "0";
        long duration = 0;
        boolean offlineAvailable = false;
        String album = "nogniks";

        while (resultSet.next()) {
            id = resultSet.getInt("id");
            performer = resultSet.getString("performer");
            titel = resultSet.getString("title");
            url = resultSet.getString("url");
            duration = resultSet.getLong("duration");
            offlineAvailable = resultSet.getBoolean("offlineAvailable");



        }
        Song nummer = new Song(album, performer, titel, url, duration);
        return nummer;

    }

//    private void writeResultSet(ResultSet resultSet) throws SQLException {
//        while (resultSet.next()) {
//            int id = resultSet.getInt("id");
//            String performer = resultSet.getString("performer");
//            String titel = resultSet.getString("title");
//            String url = resultSet.getString("url");
//            long duration = resultSet.getLong("duration");
//            boolean offlineAvailable = resultSet.getBoolean("offlineAvailable");
//
//
//
//            System.out.println("id : " + id);
//            System.out.println("performer : " + performer);
//            System.out.println("titel : " + titel);
//            System.out.println("url : " + url);
//            System.out.println("duration : " + duration);
//            System.out.println("offlineAvailable : " + offlineAvailable);
//        }
//
//        }
   // }

    @Override
    public String getAlbum(String title) {
        return null;
    }
}
