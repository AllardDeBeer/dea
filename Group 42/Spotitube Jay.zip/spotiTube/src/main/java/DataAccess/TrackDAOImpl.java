package DataAccess;

/**
 * Created by Jay on 26-3-2017.
 */
public class TrackDAOImpl implements TrackDAO {

    @Override
    public void getTrack(String title) {

    }
}
