package nl.han.oose.programmeerOpdracht;

/**
 * Created by Jay on 17-3-2017.
 */
public class Calender {

    public String wtf(){
        return "wtf jij poep tomee";
    }
}
