package nl.han.oose.programmeerOpdracht;

/**
 * Created by Jay on 16-3-2017.
 */
public class Playlist {
    private String owner;
    private String name;

    public void addTrack(Track track){

    }

    public void changeName(String name){

    }
}
