package nl.han.oose.programmeerOpdracht;

/**
 * Created by Jay on 17-3-2017.
 */
public class Song extends Track {
    private String album;

    public Song(String album, String performer, String title, String url, long duration){
        super(performer,title,url,duration);
        this.album = album;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }




}
