package nl.han.oose.programmeerOpdracht;

/**
 * Created by Jay on 17-3-2017.
 */
public class Track {


    private String performer;
    private String title;
    private String url;
    private long duration;

    public Track() {

    }

    public Track(String performer, String title, String url, long duration) {
        this.performer = performer;
        this.title = title;
        this.url = url;
        this.duration = duration;
    }

    public String getPerformer() {
        return performer;
    }

    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }

    public long getDuration() {
        return duration;
    }

    // hier staat een rare methode namelijk get/set en ik weet niet voor wat. rip.
}
