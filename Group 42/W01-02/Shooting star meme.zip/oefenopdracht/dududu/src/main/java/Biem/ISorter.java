package Biem;

import java.util.List;

/**
 * Created by Jay on 23-2-2017.
 */
public interface ISorter {

    public List<Integer> SortList(List<Integer> L);


}
