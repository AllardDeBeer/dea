package Biem;

import java.util.List;

/**
 * Created by Jay on 23-2-2017.
 */
public class bestAlgoritme implements ISorter {

    public List<Integer> SortList(List<Integer> L) {
        return null;
    }

    void nutteloos() throws mijnException{
        boolean aapje = true;
        if(aapje = false){
            return;
        }
        else throw new mijnException("Yo dit ding is true");

    }


}
