package Biem;

/**
 * Created by Jay on 23-2-2017.
 */
public class mijnException extends Exception {
    public mijnException(String message){
        super(message);
    }

}
