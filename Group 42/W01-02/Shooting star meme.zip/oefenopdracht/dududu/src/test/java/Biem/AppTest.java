package Biem;

import java.util.Collections;

import org.junit.Test;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest implements ISorter

{
    List<Integer> testLijst = new ArrayList();

    public List<Integer> SortList(List<Integer> L) {
        Collections.sort(L);
        return L;
    }


    /**
     * @return the suite of tests being tested
     */
    @Test
    public void testApp() {
        assertTrue(true);
    }

    @Test
    public void sortTest() {
        for (int i = 0; i <= 1; i++) {
            testLijst.add(i);
            testLijst.add(i * 10);
            testLijst.add(i * 3);
        }


        SortList(testLijst);
        Assert.assertEquals((10), (double)(testLijst.get(5)),0);

    }
    @Test(expected = IndexOutOfBoundsException.class)
    public void testerino() {
        testLijst.clear();
        SortList(testLijst);
        testLijst.get(0);
    }
}
