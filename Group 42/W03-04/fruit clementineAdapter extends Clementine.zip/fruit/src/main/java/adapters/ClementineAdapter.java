package adapters;

import fruit.oose.com.Citrus;
import fruit.oose.com.Clementine;

/**
 * Created by dejangonlag on 13/03/2017.
 */
public class ClementineAdapter extends Clementine implements Citrus {

    public ClementineAdapter(double w) {
        super(w);
    }

    public void eat(){
        munch();
    }
}

