package adapters;

import fruit.oose.com.Citrus;
import fruit.oose.com.Tangerine;

/**
 * Created by dejangonlag on 13/03/2017.
 */
public class TangerineAdapter implements Citrus {
    Tangerine tangerine = new Tangerine(5.00);

    public void eat(){
        tangerine.eten();
    }
}
