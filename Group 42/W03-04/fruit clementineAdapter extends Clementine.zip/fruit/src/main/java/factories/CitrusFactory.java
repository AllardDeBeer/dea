package factories;

import adapters.ClementineAdapter;
import adapters.MandarineAdapter;
import adapters.TangerineAdapter;
import fruit.oose.com.Citrus;

import java.util.Observable;

/**
 * Created by dejangonlag on 13/03/2017.
 */
public class CitrusFactory extends Observable {
    public Citrus createCitrus(String choice){
        if(choice == "Mandarine"){
            Citrus mandarine = new MandarineAdapter();
            setChanged();
            notifyObservers("Mandarine");
            return mandarine;
        } else if(choice == "Tangerine"){
            Citrus tangerine = new TangerineAdapter();
            setChanged();
            notifyObservers("Tangerine");
            return tangerine;
        } else {
            Citrus clementine = new ClementineAdapter(5.0);
            setChanged();
            notifyObservers("Clementine");
            return clementine;
        }
    }
}
