package fruit.oose.com;

/**
 * Created by dejangonlag on 13/03/2017.
 */
public class Clementine {
    private double weight;

    public Clementine(double w){
        this.weight = w;
    }

    public void munch(){
        System.out.println("Oi m8, we are eating the fruit down-under");
    }
}
