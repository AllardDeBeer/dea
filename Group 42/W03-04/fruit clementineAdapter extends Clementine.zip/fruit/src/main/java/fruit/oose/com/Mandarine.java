package fruit.oose.com;

/**
 * Created by dejangonlag on 13/03/2017.
 */
public class Mandarine {
    private double weight;

    public Mandarine(double w){
        this.weight = w;
    }

    public void essen(){
        System.out.println("Dzis item wird ge-essen");
    }
}
