package fruit.oose.com;

import java.util.Observable;
import java.util.Observer;

/**
 * Created by dejangonlag on 13/03/2017.
 */
public class Mens implements Observer{
    public void update(Observable o, Object arg) {
        System.out.println("I'm eating the" + (String)arg);
    }
}
