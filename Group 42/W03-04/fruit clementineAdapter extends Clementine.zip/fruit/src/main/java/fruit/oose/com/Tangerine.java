package fruit.oose.com;

/**
 * Created by dejangonlag on 13/03/2017.
 */
public class Tangerine {
    private double weight;

    public Tangerine(double w){
        this.weight = w;
    }

    public void eten(){
        System.out.println("De tangerine wordt gegeten Jason.");
    }
}
