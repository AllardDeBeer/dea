package adapters;

import fruit.oose.com.Citrus;
import fruit.oose.com.Mandarine;

/**
 * Created by dejangonlag on 13/03/2017.
 */
public class MandarineAdapter implements Citrus {
    Mandarine mandarine = new Mandarine(5.00);

    public void eat(){
        mandarine.essen();
    }
}
