package nl.han.oose.programmeerOpdracht;

/**
 * Created by Jay on 16-3-2017.
 */
public class Availability {
    private boolean offlineAvailable;

    public void toggle(){

    }

    public boolean isOfflineAvailable(){
        return false;
    }

}
