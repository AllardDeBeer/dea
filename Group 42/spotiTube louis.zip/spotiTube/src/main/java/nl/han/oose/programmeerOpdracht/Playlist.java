package nl.han.oose.programmeerOpdracht;

/**
 * Created by Jay on 16-3-2017.
 */
public class Playlist {
    private String owner;
    private String name;

    public Playlist(String owner, String name){
        this.owner = owner;
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
