package nl.han.oose.programmeerOpdracht;

import javax.ws.rs.GET;

/**
 * Created by Jay on 17-3-2017.
 */
public class Video  {
    private int playCount;
    private Calender publicationDate ;
    private String description;


    // hier staat een rare methode namelijk get/set en ik weet niet voor wat. rip.
}
