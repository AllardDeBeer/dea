package nl.han.oose.programmeerOpdracht.dao;

/**
 * Created by Jay on 24-3-2017.
 */
public class Main {
    public static void main(String[] args) throws Exception{
        //MYSQLAccess test = new MYSQLAccess();
           //test.readDataBase();
          // test.Insert(9002,"I'm alright-neil zaza");
          //  test.deleteAll();
        //SongDAOImpl tester = new SongDAOImpl();
//        Song aapje = tester.get("skrt");
//        System.out.println(aapje.getPerformer());
//
//        PlaylistDAOImpl tester2 = new PlaylistDAOImpl();
//        List<Playlist> playlists = tester2.get();
//
//        for (int i = 0; i < playlists.size(); i++) {
//            System.out.println(playlists.get(i).name);
//        }
    }
}
