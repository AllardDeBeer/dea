package nl.han.oose.programmeerOpdracht.dao;

import nl.han.oose.programmeerOpdracht.Playlist;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface PlaylistDAO {
    Playlist get(String title) throws Exception;
    String getAlbum(String title);
    Playlist mapResultSet(ResultSet resultSet) throws SQLException;
}
