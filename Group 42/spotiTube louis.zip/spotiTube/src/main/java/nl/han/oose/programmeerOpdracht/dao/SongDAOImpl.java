package nl.han.oose.programmeerOpdracht.dao;

import nl.han.oose.programmeerOpdracht.Song;

import java.sql.*;

public class SongDAOImpl extends Model implements SongDAO {
    @Override
    public Song get(String title) throws Exception {
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM tracks WHERE title = ?");
            stmt.setString(1, title);

            Song song = this.mapResultSet(stmt.executeQuery());
            return song;
        } catch (Exception err) {
            err.printStackTrace();
        } finally {
            this.close();
        }
        return null;
    }

    public Song mapResultSet(ResultSet resultSet) throws SQLException {
        int id = 0;
        String performer ="0";
        String titel="0";
        String url = "0";
        long duration = 0;
        boolean offlineAvailable = false;
        String album = "nogniks";

        while (resultSet.next()) {
            id = resultSet.getInt("id");
            performer = resultSet.getString("performer");
            titel = resultSet.getString("title");
            url = resultSet.getString("url");
            duration = resultSet.getLong("duration");
            offlineAvailable = resultSet.getBoolean("offlineAvailable");
        }
        Song nummer = new Song(album, performer, titel, url, duration);
        return nummer;

    }

//    private void writeResultSet(ResultSet resultSet) throws SQLException {
//        while (resultSet.next()) {
//            int id = resultSet.getInt("id");
//            String performer = resultSet.getString("performer");
//            String titel = resultSet.getString("title");
//            String url = resultSet.getString("url");
//            long duration = resultSet.getLong("duration");
//            boolean offlineAvailable = resultSet.getBoolean("offlineAvailable");
//
//
//
//            System.out.println("id : " + id);
//            System.out.println("performer : " + performer);
//            System.out.println("titel : " + titel);
//            System.out.println("url : " + url);
//            System.out.println("duration : " + duration);
//            System.out.println("offlineAvailable : " + offlineAvailable);
//        }
//
//        }
   // }

    @Override
    public String getAlbum(String title) {
        return null;
    }
}
