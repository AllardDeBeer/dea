package nl.han.oose.programmeerOpdracht.dao;

/**
 * Created by Jay on 26-3-2017.
 */
public interface TrackDAO {
    public void getTrack(String title);

}
