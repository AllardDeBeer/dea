package nl.han.oose.programmeerOpdracht.presentation.Servlets;

import nl.han.oose.programmeerOpdracht.dao.PlaylistDAOImpl;
import nl.han.oose.programmeerOpdracht.Playlist;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by louis on 28-3-2017.
 */
@WebServlet("/index")
public class indexServlet extends HttpServlet {

    @Inject
    PlaylistDAOImpl playlister;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            List<Playlist> alleplaylists = playlister.getAllPlaylists();

            req.setAttribute("playLists", alleplaylists);
            req.getRequestDispatcher("index.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
