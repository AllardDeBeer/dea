package nl.han.oose.programmeerOpdracht.DataAccess;
import java.sql.*;

/**
 * Created by Jay on 23-3-2017.
 */

public class MYSQLAccess {
    private Connection connect = null;
    private Statement statement = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;

    public void readDataBase() throws Exception {
        try {
            // This will load the MySQL driver, each DB has its own driver
            Class.forName("com.mysql.jdbc.Driver");
            // Setup the connection with the DB
            connect = DriverManager
                    .getConnection("jdbc:mysql://localhost/spotitube?"
                            + "user=sqluser&password=koekje");

            // Statements allow to issue SQL queries to the database
            statement = connect.createStatement();
            // Result set get the result of the SQL query
            resultSet = statement
                    .executeQuery("SELECT * FROM suckmyrockingcock");
            writeResultSet(resultSet);

            // PreparedStatements can use variables and are more efficient


//            preparedStatement = connect
//                    .prepareStatement("SELECT IntTest from koekjes.suckmyrockingcock");
//            resultSet = preparedStatement.executeQuery();
//            writeResultSet(resultSet);


//            resultSet = statement
//                    .executeQuery("select * from koekjes.suckmyrockingcock");
//            writeMetaData(resultSet);

        } catch (Exception e) {
            throw e;
       } finally {
           close();
        }

    }

    public void Insert(int column1, String column2) throws SQLException {
        connect = DriverManager
                .getConnection("jdbc:mysql://localhost/koekjes?"
                        + "user=sqluser&password=sqluserpw");
        preparedStatement = connect
               .prepareStatement("insert into  suckmyrockingcock values (?, ?)");
        // " int en string;
        // Parameters start with 1
        preparedStatement.setInt(1,column1 );
        preparedStatement.setString(2, column2);
        preparedStatement.executeUpdate();
        close();
    }

    public void deleteAll() throws SQLException {
        connect = DriverManager
                .getConnection("jdbc:mysql://localhost/koekjes?"
                        + "user=sqluser&password=sqluserpw");
        preparedStatement = connect
                .prepareStatement("DELETE FROM suckmyrockingcock");
        preparedStatement.executeUpdate();
        close();
    }

    private void writeMetaData(ResultSet resultSet) throws SQLException {
        //         Now get some metadata from the database
        // Result set get the result of the SQL query

        System.out.println("The columns in the table are: ");

        System.out.println("Table: " + resultSet.getMetaData().getTableName(1));
        for  (int i = 1; i<= 2; i++){
            System.out.println("Column " +i  + " "+ resultSet.getMetaData().getColumnName(i));
        }
    }

    private void writeResultSet(ResultSet resultSet) throws SQLException {
        // ResultSet is initially before the first data set
        while (resultSet.next()) {
            // It is possible to get the columns via name
            // also possible to get the columns via the column number
            // which starts at 1
            // e.g. resultSet.getSTring(2);
            int testInt = resultSet.getInt("IntTest");
            String StringTest = resultSet.getString("StringTest");
            System.out.println("User: " + testInt);
            System.out.println("Website: " + StringTest);

        }
    }

    // You need to close the resultSet
    private void close() {
        try {
            if (resultSet != null) {
                resultSet.close();
            }

            if (statement != null) {
                statement.close();
            }

            if (connect != null) {
                connect.close();
            }
        } catch (Exception e) {

        }
    }

}
