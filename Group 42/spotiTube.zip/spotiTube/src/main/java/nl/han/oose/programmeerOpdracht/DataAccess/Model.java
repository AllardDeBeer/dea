package nl.han.oose.programmeerOpdracht.DataAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by rbozan on 28/03/17.
 */
public class Model {
    protected Connection conn = null;

    public Model() {
        try {
            this.getConnection();
        } catch (Exception err) {
            err.printStackTrace();
        }
    }

    protected void close() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {

        }
    }

    protected void getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        this.conn = DriverManager.getConnection("jdbc:mysql://localhost/spotitube?user=admin&password=admin");
    }
}
