package nl.han.oose.programmeerOpdracht.DataAccess;

import nl.han.oose.programmeerOpdracht.Playlist;
import nl.han.oose.programmeerOpdracht.Song;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface PlaylistDAO {
    Playlist get(String title) throws Exception;
    String getAlbum(String title);
    Playlist mapResultSet(ResultSet resultSet) throws SQLException;
}
