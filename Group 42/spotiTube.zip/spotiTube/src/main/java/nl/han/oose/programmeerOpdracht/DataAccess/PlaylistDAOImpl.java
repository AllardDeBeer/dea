package nl.han.oose.programmeerOpdracht.DataAccess;

import nl.han.oose.programmeerOpdracht.Playlist;
import nl.han.oose.programmeerOpdracht.Song;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlaylistDAOImpl extends Model implements PlaylistDAO {
    @Override
    public Playlist get(String title) throws Exception {
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM playlists WHERE title = ?");
            stmt.setString(1, title);

            Playlist instance = this.mapResultSet(stmt.executeQuery());
            return instance;
        } catch (Exception err) {
            err.printStackTrace();
        } finally {
            this.close();
        }
        return null;
    }

    public List<Playlist> get() {
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM playlists");
            List<Playlist> instances = this.mapAllResults(stmt.executeQuery());
            return instances;
        } catch (Exception err) {
            err.printStackTrace();
        } finally {
            this.close();
        }
        return null;
    }

    public List<Playlist> mapAllResults(ResultSet resultSet) throws SQLException {
        int id = 0;
        String owner = null;
        String name = null;

        List<Playlist> results = new ArrayList<>();

        while (resultSet.next()) {
            System.out.println(" got next");
            id = resultSet.getInt("id");
            owner = resultSet.getString("owner");
            name = resultSet.getString("name");
            results.add(new Playlist(owner, name));
        }
        return results;
    }

    public Playlist mapResultSet(ResultSet resultSet) throws SQLException {
        int id = 0;
        String owner = null;
        String name = null;

        while (resultSet.next()) {
            System.out.println(" got next");
            id = resultSet.getInt("id");
            owner = resultSet.getString("owner");
            name = resultSet.getString("name");
        }
        Playlist instance = new Playlist(owner, name);
        return instance;

    }

//    private void writeResultSet(ResultSet resultSet) throws SQLException {
//        while (resultSet.next()) {
//            int id = resultSet.getInt("id");
//            String performer = resultSet.getString("performer");
//            String titel = resultSet.getString("title");
//            String url = resultSet.getString("url");
//            long duration = resultSet.getLong("duration");
//            boolean offlineAvailable = resultSet.getBoolean("offlineAvailable");
//
//
//
//            System.out.println("id : " + id);
//            System.out.println("performer : " + performer);
//            System.out.println("titel : " + titel);
//            System.out.println("url : " + url);
//            System.out.println("duration : " + duration);
//            System.out.println("offlineAvailable : " + offlineAvailable);
//        }
//
//        }
    // }

    @Override
    public String getAlbum(String title) {
        return null;
    }
}
