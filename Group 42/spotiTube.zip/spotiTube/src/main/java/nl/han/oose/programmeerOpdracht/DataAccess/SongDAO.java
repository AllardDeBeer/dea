package nl.han.oose.programmeerOpdracht.DataAccess;

import nl.han.oose.programmeerOpdracht.Song;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface SongDAO {
    Song get(String title) throws Exception;
    String getAlbum(String title);
    Song mapResultSet(ResultSet resultSet) throws SQLException;
}
