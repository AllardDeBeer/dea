package nl.han.meron.domain.crowdbehaviour;

public enum AgressionLevel {
    Low,
    Medium,
    High
}
